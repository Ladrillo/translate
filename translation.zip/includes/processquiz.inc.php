<?php

if($_POST['polla'] == $row["qtext1"]) {

    $andtheansweris = 'There you go!';
}

else {

    $andtheansweris = 'Wrong answer!';
}

