<!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Intro Form</title>
</head>

<body>
    <div class="container">
        <form action="?" method="post">
            <label for="qtext1">Question Text 1: <br><textarea id="qtext1" name="qtext1" rows="2" cols="100" maxlength="200"></textarea></label><br>
            <label for="qtext2">Question Text 2: <br><textarea id="qtext2" name="qtext2" rows="2" cols="100" maxlength="200"></textarea></label><br>
            <label for="answ1">Answer 1: <br><textarea id="answ1" name="answ1" rows="2" cols="100" maxlength="200"></textarea></label><br>
            <label for="answ2">Answer 2: <br><textarea id="answ2" name="answ2" rows="2" cols="100" maxlength="200"></textarea></label><br>
            <label for="hint">Hint: <br><textarea id="hint" name="hint" rows="2" cols="100" maxlength="200"></textarea></label><br>
            <input type="submit" value="submit">
        </form>
    </div>
</body>

</html>