<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Output</title>
</head>

<body>
    <div class="container">
        <p><?php echo $output; ?></p>
        <h1><?php echo $andtheansweris ?></h1>
    </div>
</body>

</html>