<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>My first Web App</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<body>
    <div class="container">
        <header>
        <h1>This is my first Webapp</h1>
        <ul>
            <li><a href="?addquestion">Add new question to database</a></li>
            <li><a href="?showall">Display all questions in database</a></li>
            <li><a href="?quiz">Run a quiz</a></li>
        </ul>
        </header>
    </div>
</body>

</html>